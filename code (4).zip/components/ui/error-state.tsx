"use client"

import { AlertCircle } from "lucide-react"

interface ErrorStateProps {
  title: string
  description: string
  onRetry?: () => void
}

export function ErrorState({ title, description, onRetry }: ErrorStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 bg-destructive/5 border border-destructive/20 rounded-lg">
      <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center mb-4">
        <AlertCircle className="w-6 h-6 text-destructive" />
      </div>
      <h3 className="text-lg font-semibold text-destructive mb-1 text-center">{title}</h3>
      <p className="text-sm text-destructive/70 text-center mb-6 max-w-sm">{description}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-4 py-2 bg-destructive/10 text-destructive rounded-lg font-medium transition-all duration-200 hover:bg-destructive/20 active:scale-95 border border-destructive/20"
        >
          Reintentar
        </button>
      )}
    </div>
  )
}
