"use client"

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`bg-muted/60 animate-shimmer rounded ${className}`} />
}

export function SkeletonCard() {
  return (
    <div className="bg-card/60 border border-border rounded-lg p-6 space-y-4">
      <Skeleton className="h-6 w-24" />
      <Skeleton className="h-10 w-full" />
      <Skeleton className="h-4 w-32" />
    </div>
  )
}

export function SkeletonTable() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex gap-4">
          <Skeleton className="h-10 w-10 rounded" />
          <Skeleton className="h-10 flex-1" />
          <Skeleton className="h-10 w-24" />
        </div>
      ))}
    </div>
  )
}
