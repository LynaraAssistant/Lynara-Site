"use client"

import type React from "react"

import { InboxIcon } from "lucide-react"

interface EmptyStateProps {
  title: string
  description: string
  icon?: React.ReactNode
  action?: {
    label: string
    onClick: () => void
  }
}

export function EmptyState({ title, description, icon, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 bg-card/40 border border-dashed border-border rounded-lg">
      <div className="w-12 h-12 rounded-lg bg-muted/60 flex items-center justify-center mb-4 text-muted-foreground">
        {icon || <InboxIcon className="w-6 h-6" />}
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-1 text-center">{title}</h3>
      <p className="text-sm text-muted-foreground text-center mb-6 max-w-sm">{description}</p>
      {action && (
        <button
          onClick={action.onClick}
          className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium transition-all duration-200 hover:bg-primary/90 active:scale-95"
        >
          {action.label}
        </button>
      )}
    </div>
  )
}
