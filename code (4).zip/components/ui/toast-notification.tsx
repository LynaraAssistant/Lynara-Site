"use client"

import { X, Check, AlertCircle, Info } from "lucide-react"
import { useEffect, useState } from "react"

type ToastType = "success" | "error" | "info" | "warning"

interface ToastNotificationProps {
  message: string
  type?: ToastType
  duration?: number
  onClose: () => void
}

export function ToastNotification({ message, type = "info", duration = 3000, onClose }: ToastNotificationProps) {
  const [isClosing, setIsClosing] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsClosing(true)
      setTimeout(onClose, 200)
    }, duration)

    return () => clearTimeout(timer)
  }, [duration, onClose])

  const typeConfig = {
    success: {
      bg: "bg-emerald-500/10",
      border: "border-emerald-500/20",
      icon: Check,
      color: "text-emerald-600 dark:text-emerald-400",
    },
    error: {
      bg: "bg-destructive/10",
      border: "border-destructive/20",
      icon: AlertCircle,
      color: "text-destructive",
    },
    info: {
      bg: "bg-blue-500/10",
      border: "border-blue-500/20",
      icon: Info,
      color: "text-blue-600 dark:text-blue-400",
    },
    warning: {
      bg: "bg-amber-500/10",
      border: "border-amber-500/20",
      icon: AlertCircle,
      color: "text-amber-600 dark:text-amber-400",
    },
  }

  const config = typeConfig[type]
  const Icon = config.icon

  return (
    <div
      className={`fixed bottom-4 right-4 flex items-center gap-3 px-4 py-3 rounded-lg border ${config.bg} ${config.border} transition-all duration-200 ${
        isClosing ? "opacity-0 translate-x-4" : "opacity-100 translate-x-0 animate-slide-in"
      }`}
    >
      <Icon className={`w-5 h-5 flex-shrink-0 ${config.color}`} />
      <span className="text-sm font-medium text-foreground">{message}</span>
      <button
        onClick={() => {
          setIsClosing(true)
          setTimeout(onClose, 200)
        }}
        className="ml-2 p-1 hover:bg-black/5 dark:hover:bg-white/5 rounded transition-colors"
      >
        <X className="w-4 h-4 text-muted-foreground" />
      </button>
    </div>
  )
}
